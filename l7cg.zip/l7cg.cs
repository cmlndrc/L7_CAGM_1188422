namespace T7_CG_1188422
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int cant;
            int a, b, c;
            Console.WriteLine("Ingresar numero: ");
            cant = Int32.Parse(Console.ReadLine());
            a = 0; b = 1;
            Console.Write(a + " " + b + " ");
            for (int k = 3; k <= cant; k++)
            {
                c = a + b;
                Console.Write(c + " ");
                a = b;
                b = c;
            }
            Console.ReadKey();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}